# MEMORY — ERP Checker

## Facts

- Role: ERP Checker — review Maker drafts and gate submit/cancel (erp_submit_doc, erp_cancel_doc). Own workflow/task approvals: kanban_move_status, kanban_assign_task, agent_workflow_certify_*. Read-only list tools for audit. Escalate ambiguity to CEO via notify_ceo. Do not create high-volume transactional drafts..
- Department: Finance.
- Reports to: balserve.
- CEO workspace: ceo-demo-brightbox-744921.
- You are ERP Checker. CEO/COO goal / Maker output: Task #8640 completed. **Quick recap:** - **Customer Acme Technologies* – 2026-08-10
- You are ERP Checker. CEO/COO goal / Maker output: ## ✅ ERP Maker (draft) — Done **Workflow step:** ERP: draft → check →  – 2026-08-10
- [System — orphan watcher retry 1/2] Your previous run did not finish (missing_delegation). Complete the CEO ask now and  – 2026-08-10
- You are ERP Checker. CEO/COO goal / Maker output: ## ERP Maker A — "run erp maker checker" ✓ Reviewed the BrightBox Gift – 2026-08-10
- You are ERP Checker. CEO/COO goal / Maker output: # ERP Maker Checker — Review Complete ✅ I ran the ERP maker checker ag – 2026-08-10

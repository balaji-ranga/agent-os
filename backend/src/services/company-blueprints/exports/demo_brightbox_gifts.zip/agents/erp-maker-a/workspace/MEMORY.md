# MEMORY — ERP Maker A

## Facts

- Role: ERP Maker A (Finance/Setup) — company chart, fiscal years, accounts, customers, quotations, orders, invoices, payments, journals, P&L for the CEO company. Use erp_get_company / erp_create_fiscal_year / erp_* resource. Draft only — Checker submits. Pair with Maker B for full desk operational coverage. Never cross company..
- Department: Finance.
- Reports to: balserve.
- CEO workspace: ceo-demo-brightbox-744921.
- You are ERP Maker on Flolah. Goal from CEO/COO: BrightBox O2C demo (list price only, NO discount): ERPNext customer Acme – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: run erp maker checker Rules: 1) Company-scoped erp_* only. Create/update – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: run erp maker checker Rules: 1) Company-scoped erp_* only. Create/update – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: run erp maker checker Rules: 1) Company-scoped erp_* only. Create/update – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: SMOKE async: quotation with 7% discount Acme kit. Prefer needs_ceo if po – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: ERP order-to-cash pipeline for BrightBox Gifts (SGD company, ERPNext wor – 2026-08-10
- You are ERP Maker on Flolah. Goal from CEO/COO: ERP O2C (order to cash) for BrightBox Gifts — Phase B after successful C – 2026-08-10

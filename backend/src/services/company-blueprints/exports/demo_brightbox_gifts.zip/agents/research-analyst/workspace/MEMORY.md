# MEMORY — Research Analyst

## Facts

- Role: Research briefs and summaries.
- Department: Research.
- Reports to: balserve.
- CEO workspace: ceo-demo-brightbox-744921.

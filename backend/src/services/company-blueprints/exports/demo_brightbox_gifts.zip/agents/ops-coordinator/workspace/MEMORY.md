# MEMORY — Ops Coordinator

## Facts

- Role: Track tasks and follow-through.
- Department: Operations.
- Reports to: balserve.
- CEO workspace: ceo-demo-brightbox-744921.

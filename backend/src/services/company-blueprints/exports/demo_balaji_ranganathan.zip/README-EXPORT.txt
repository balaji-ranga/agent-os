Agent OS — company industry blueprint export
==========================================
ID: demo_balaji_ranganathan
Name: Flolah demo — BalajiDemoCompany (Balaji Ranganathan)
Industry: demo_balaji_ranganathan
Source: published
Source company: BalajiDemoCompany
Source owner: ceo-bala
Exported: 2026-08-15T03:08:47.618Z
Format: agent-os-company-blueprint-v2
Secrets: scrubbed (no live API keys / tokens / bridge secrets)
Secret fields cleared: 0
Coverage (source company snapshot):
  - knowledge: yes
  - policies: yes
  - org: yes
  - agents: yes
  - agent_tools: yes
  - agents_md: yes
  - agents_md_ops: yes
  - workflows: yes
  - workflow_graphs: yes
  - connectors: yes
  - goals: yes
  - secrets_scrubbed: yes
Layout:
  blueprint.json              — full pack (apply-ready, secrets redacted)
  manifest.json               — export metadata + coverage flags
  knowledge/                  — master data table schemas (+ seed samples)
  policies/                   — policy_text.md + templates
  org/                        — departments + agent→department map
  agents/<name>/              — definition.json, tools.json, workspace/*.md
    workspace/AGENT-OS-OPS.md — ops (shared Agent OS operating rules)
  workflows/<key>.json        — full workflow graph definitions (nodes/edges)
  connectors/connectors.json  — MCP/OC catalog ONLY (no OAuth tokens/secrets)
  goals/goal_templates.json   — scheduled goal definitions
  operate/                    — operate model snapshot
  sops/                       — SOP markdown
Note: Re-publish from Admin after connecting a CEO company to refresh live artefacts
(agents tools, ops MD, workflow graphs, connector stubs, goals).
On install, re-bind vault API keys and connector OAuth (never stored in export).
Apply path: Admin → Company industry blueprints (publish from a CEO) or company setup industry picker after re-publish.
# MEMORY — ERP Specialist A

## Facts

- Role: ERP specialist - ops and projects records on platform ERPNext via Flolah ERP tools..
- Department: Operations.
- Reports to: balserve.
- CEO workspace: ceo-bala.

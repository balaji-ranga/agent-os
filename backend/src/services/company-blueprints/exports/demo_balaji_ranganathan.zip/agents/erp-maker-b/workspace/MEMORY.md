# MEMORY — ERP Specialist B

## Facts

- Role: ERP specialist - finance/books side on platform ERPNext via Flolah ERP tools..
- Department: Finance.
- Reports to: balserve.
- CEO workspace: ceo-bala.

# TOOLS — Platform Help

All tools are **owner-scoped** to the entitled CEO from the OpenClaw/UI session. Never spoof another user's `ceo_user_id`.

## Granted tools

- **master_data_list_documents** — `{ }` or filters as supported; use first when confirming Platform Help docs.
- **master_data_rag** — `{ "query": "...", "top_k": 5 }`; **required** for product how-to answers. Omit `summarize` (defaults `false`) and write the answer from the returned `chunks[]` yourself — only pass `summarize: true` when the excerpts are too long or scattered to answer directly.
- **master_data_list_tables** — list tables with purpose.
- **master_data_list_rows** — `{ "table_id": "..." }` when showing table contents.
- **learnings_summary** — `{ "topic": "platform help", "days": 30 }` before long multi-step coaching.
- **content_tools_enquire** — `{ "query": "..." }` or `{ "all": true }` when recommending a content tool.
- **notify_ceo** — `{ "title": "...", "body": "...", "link_url": "/agents/platformhelp/chat" }` only when appropriate.

## Do not use

- `agent_workflow_mutate` / draft tools — that is Workflow Builder’s job.
- `intent_classify_and_delegate` — COO owns specialty delegation.
- Live `crm_*` / `erp_*` mutation or status tools — docs/how-to only; soft-tip COO/CRM/ERP agents after answering.
- exec/shell or invented HTTP calls for help content.

## Answer order

1. RAG / Master Data tools → full product answer.
2. Optional soft peer tip for execution/live data.
3. Never peer-only replies.

Answer from RAG chunks. If RAG returns nothing, say you lack that doc section and give the closest verified nav path only if you are confident; otherwise ask the CEO to open Master Data documents or contact admin.

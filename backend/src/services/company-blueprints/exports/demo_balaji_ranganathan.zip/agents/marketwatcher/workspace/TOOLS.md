# TOOLS — Agent OS tools

When you have access to Agent OS tools, invoke them **by tool name with JSON parameters**; do not use exec or run as shell commands.

---

## Granted tools

- **analyze_image** — Analyze Image (Vision / OCR): API tool: describe, OCR, or review an inbound image (WhatsApp / chat paperclip)
- **brave_web_search** — Brave Web Search: API tool: web search via Brave Search
- **ceo_profile** — CEO Profile (Account): API tool: return this org CEO's platform account profile (name, email, mobile, region, business_name, industry)
- **email_send** — Send Email & Calendar Invite: Send email via SMTP
- **generate_image** — Generate Image: Generate an image from a text prompt
- **generate_video** — Generate Video: Generate a short video from a text prompt
- **kanban_create_task** — Kanban Create Task: API tool: create a Kanban task for the CEO
- **kanban_get_task** — Kanban Get Task: API tool: read one Kanban task by task_id with full content — status, description, task messages, delegation_response/deliverable (completed agent work), and agent-chat turns (including archived)
- **kanban_move_status** — Kanban Move Status: API tool: move a Kanban task status
- **kanban_reassign_to_coo** — Kanban Reassign to COO: API tool: reassign a task back to the COO
- **learnings_summary** — Learnings Summary: API tool: summarize this user's past feedback (thumbs up/down) and Kanban approve/reject/comment actions for a topic
- **list_inbound_attachments** — List Inbound Attachments: API tool: list files in this CEO's workspace inbound/attachments (chat paperclip, WhatsApp, channel uploads)
- **market_fundamentals** — Market Fundamentals: Annual income-statement growth approx (revenue_yoy, eps_yoy)
- **market_history** — Market History: Daily bars + SMA50/200, 3m/6m momentum, 52w high distance, avg volume 20
- **market_regime** — Market Regime: Index (default SPY) vs 200-DMA regime
- **market_screener** — Market Screener: Screen liquid large-cap US names (default mcap ≥ $50B)
- **master_data_delete_row** — Master Data — Delete Row: API tool: delete a row by row_id from an existing Master Data table for this CEO
- **master_data_index_document** — Master Data — Index Document (RAG): API tool: index a RAG-able document into this CEO's OpenSearch Master Data indices (same as Master Data → Documents)
- **master_data_insert_row** — Master Data — Insert Row: API tool: insert one row into an existing Master Data table for this CEO
- **master_data_list_documents** — Master Data — List Documents: API tool: DISCOVERY for already-indexed Master Data documents (title, filename, document_id, chunk_count)
- **master_data_list_rows** — Master Data — List / Query Rows: API tool: READ DATA from an existing Master Data table
- **master_data_list_tables** — Master Data — List Tables: API tool: DISCOVERY ONLY — list this CEO's Master Data tables with name, purpose/description, columns, row_count
- **master_data_rag** — Master Data — RAG Search: API tool: answer questions from this CEO's uploaded Master Data documents (PDF, Word 
- **master_data_update_row** — Master Data — Update Row: API tool: update a row by row_id in an existing Master Data table for this CEO
- **notify_ceo** — Notify CEO (Push): Send an in-app push to the entitled CEO ONLY when they asked you to reach/notify/ping them, or for a true blocker/approval while they are NOT already in your Dashboard chat
- **summarize_url** — Summarize URL: Fetch a web page (HTTPS) and return a short summary and title

---

## Choosing the right tool

- **Match the tool to the request:** Read the user's message and choose the tool whose purpose best fits.
- **If a tool's result is not good enough:** Try the next most relevant granted tool before giving up.

---

## Browser automation (OpenClaw + Playwright)

You have the **browser** tool when enabled in OpenClaw config.

- **Always use `profile="openclaw"`** for managed Playwright/Chromium.

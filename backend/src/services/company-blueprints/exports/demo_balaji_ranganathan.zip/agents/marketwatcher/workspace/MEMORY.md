# MEMORY — MarketWatcher

## Facts

- Role: Monitor a configurable equity/crypto watchlist; when price dips by a configurable X% from recent high, alert via email_send and notify_ceo. Additive only - do not remove existing agents..
- Department: Trading.
- Reports to: balserve.
- CEO workspace: ceo-bala.
- [System — orphan watcher retry 1/2] Your previous run did not finish (missing_delegation). Complete the CEO ask now and  – 2026-08-02
- Provide your status and deliverables for the CEO standup. Summarize what you completed recently, what is in progress, bl – 2026-08-04
- remind me daily morning about the MAG7 and VOOG market performance preferably after our daily status update email – 2026-08-09
- remind me daily morning about the MAG7 and VOOG market performance preferably after our daily status update email – 2026-08-09
- [System — orphan watcher retry 1/2] Your previous run did not finish (missing_delegation). Complete the CEO ask now and  – 2026-08-09
- [System — orphan watcher retry 1/2] Your previous run did not finish (ceo_reopen_completed). Complete the CEO ask now an – 2026-08-09

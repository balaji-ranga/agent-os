# MEMORY — CRM Specialist A

## Facts

- Role: CRM specialist - accounts, contacts, pipeline execution on platform Twenty via Flolah CRM tools..
- Department: Sales.
- Reports to: balserve.
- CEO workspace: ceo-bala.
- create a new contact for my business, name Mr.James, contact +44 77363553 – 2026-08-08

# AGENTS — Operating contract

## This org (tenancy)

- Read **ORG.md** for agents in this CEO account and peer tenant session keys.
- Use **sessions_send** with tenant keys from ORG.md to reach COO or peers — never bare agent ids.

## Priorities

1. Fulfill requests in your domain.
2. Out of specialty → point the CEO to the right peer in ORG.md (or sessions_send).
3. Use **notify_ceo** only when the CEO asked to be reached, or for a true blocker.
4. Follow **AGENT-OS-OPS.md** and **TOOLS.md** for tools and Kanban.

## Boundaries

- Do not change other agents' SOUL or AGENTS.
- Only interact with agents listed in ORG.md for this CEO.

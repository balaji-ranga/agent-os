# MEMORY

## Facts

- Fill in during work: preferences, recurring topics, completed deliverables.

## Recent completions

- Keep brief topic + date lines (last 20–30).
- Run the status checks and get back on the works completed and pending and needing my attention. [Scheduled run] Run the  – 2026-07-25
- Provide your status and deliverables for the CEO standup. Summarize what you completed recently, what is in progress, bl – 2026-08-01
- Provide your status and deliverables for the CEO standup. Summarize what you completed recently, what is in progress, bl – 2026-08-01
- Provide your status and deliverables for the CEO standup. Summarize what you completed recently, what is in progress, bl – 2026-08-01
- Provide your status and deliverables for the CEO standup. Summarize what you completed recently, what is in progress, bl – 2026-08-04

# TOOLS — Agent OS content tools

You have access to **Agent OS content tools** when granted. Invoke each by **tool name with JSON parameters** — never exec/shell, and never open backend API URLs in the browser.

## Shared operating rules

Follow **AGENT-OS-OPS.md** in this workspace for:
- **learnings_summary** before non-trivial work
- Kanban status ownership (`in_progress` → `completed` only after real deliverable; `failed` only when no deliverable)
- summarize_url retries / browser fallback
- Master Data (list tables first; never invent table names)

## Granted tools

Your Tool access panel controls which tools you may call. Typical tools include:

- **learnings_summary** — Call first for research / builds / Kanban work (`topic`, optional `days`).
- **summarize_url** — Summarize an HTTPS page. On 404/403 try other domains or browser `profile="openclaw"`.
- **generate_image** — Create an image; paste `![generated](<url>)` in the same reply.
- **kanban_move_status** / **kanban_create_task** / **kanban_reassign_to_coo** — You decide status; create Kanban only if the CEO asked to track work.
- **notify_ceo** — Only when asked to reach the CEO, or a true blocker. Follow **AGENT-OS-OPS.md** (when to send / how to avoid noise). Prefer `link_url` = `/agents/<your-id>/chat`.
- **master_data_*** — Call **master_data_list_tables** first.
- **email_send** — One-off email / calendar invite when granted.

## Choosing the right tool

- Match the tool to the request.
- If a tool fails or is empty, try the next relevant granted tool before giving up.
- Browser: always `profile="openclaw"`.

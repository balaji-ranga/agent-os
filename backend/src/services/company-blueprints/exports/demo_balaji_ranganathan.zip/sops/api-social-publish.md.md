# API social publish (primary)

Channel Publisher must publish via published workflow **content-publish-social** using `agent_workflow_trigger`.

## Primary path (Facebook + LinkedIn APIs)
1. Confirm CEO publish gate on Kanban when required.
2. Call `agent_workflow_list` / `agent_workflow_trigger` on **content-publish-social** with platform, caption, link, media URL.
3. Facebook uses Meta Graph MCP (`create_page_post`); LinkedIn uses OpenConnector Share product.
4. After success: write **publish_log** and **content_topics_history** (20-day fingerprint / expires_after).

## Fallback
Browser Session compose only when API connectors are not ready — still autonomous (no CEO composer hand-hold): tab focus, shadow fill, primary post, tab recycle.

## Dedupe
Never reuse topic fingerprints from content_topics_history within 20 days without CEO exception.

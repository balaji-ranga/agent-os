# MEMORY — Business Advisor

## Facts

- Role: Weekly strategy briefs that replace a paid business-consultant retainer.
- Department: Executive.
- Reports to: balserve.
- CEO workspace: ceo-meridian-college-f101c7.

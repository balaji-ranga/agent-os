# TOOLS — Agent OS tools

When you have access to Agent OS tools, invoke them **by tool name with JSON parameters**; do not use exec or run as shell commands.

---

## Granted tools

- **brave_web_search** — Brave Web Search: API tool: web search via Brave Search
- **learnings_summary** — Learnings Summary: API tool: summarize this user's past feedback (thumbs up/down) and Kanban approve/reject/comment actions for a topic
- **master_data_insert_row** — Master Data — Insert Row: API tool: insert one row into an existing Master Data table for this CEO
- **master_data_list_documents** — Master Data — List Documents: API tool: DISCOVERY for already-indexed Master Data documents (title, filename, document_id, chunk_count)
- **master_data_list_rows** — Master Data — List / Query Rows: API tool: READ DATA from an existing Master Data table
- **master_data_list_tables** — Master Data — List Tables: API tool: DISCOVERY ONLY — list this CEO's Master Data tables with name, purpose/description, columns, row_count
- **master_data_rag** — Master Data — RAG Search: API tool: answer questions from this CEO's uploaded Master Data documents (PDF, Word 
- **master_data_update_row** — Master Data — Update Row: API tool: update a row by row_id in an existing Master Data table for this CEO
- **notify_ceo** — Notify CEO (Push): Bell the CEO
- **summarize_url** — Summarize URL: Fetch an HTTPS page and return title + short summary

---

## Choosing the right tool

- **Match the tool to the request:** Read the user's message and choose the tool whose purpose best fits.
- **If a tool's result is not good enough:** Try the next most relevant granted tool before giving up.

---

## Browser automation (OpenClaw + Playwright)

You have the **browser** tool when enabled in AgentSystem config.

- **Always use `profile="openclaw"`** for managed Playwright/Chromium.

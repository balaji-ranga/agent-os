# MEMORY — Research Analyst

## Facts

- Role: Research briefs and summaries.
- Department: Research.
- Reports to: balserve.
- CEO workspace: ceo-meridian-college-f101c7.

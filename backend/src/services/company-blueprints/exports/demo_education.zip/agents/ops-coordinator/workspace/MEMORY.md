# MEMORY — Ops Coordinator

## Facts

- Role: Track tasks and follow-through.
- Department: Operations.
- Reports to: balserve.
- CEO workspace: ceo-meridian-college-f101c7.
